package com.sj.gourmet;

public class GourmetInfo {
	private String name; // 상호명
	private String tel; // 전화번호
	private String menu; // 메뉴
	private String addr; // 주소
	private String img;
		
	public GourmetInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public GourmetInfo(String name, String tel, String menu, String addr, String img) {
		super();
		this.name = name;
		this.tel = tel;
		this.menu = menu;
		this.addr = addr;
		this.img = img;
	}
	
	}
	